package simulator.model.gestorregion;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Predicate;

import org.json.JSONArray;
import org.json.JSONObject;

import simulator.misc.Vector2D;
import simulator.model.animal.Animal;
import simulator.model.region.DefaultRegion;
import simulator.model.region.Region;

public class RegionManager implements AnimalMapView {

	// Atributos
	private final int width;
	private final int height;
	private final int numCols;
	private final int numRows;
	private final int width_Region;
	private final int height_Region;
	private Map<Animal, Region> _animal_region;
	private Region[][] _regions;

	// Constructora
	public RegionManager(int cols, int rows, int width, int height) {
		if (cols == 0 || rows == 0)
			throw new IllegalArgumentException("The cols or rows must be a number greater than zero");
		this.numCols = cols;
		this.numRows = rows;
		this.width = width;
		this.height = height;
		this.width_Region = width / cols;
		this.height_Region = height / rows;

		this._regions = new Region[rows][cols];
		for (int i = 0; i < rows; i++) {
			for (int j = 0; j < cols; j++) {
				this._regions[i][j] = new DefaultRegion();
			}
		}

		this._animal_region = new HashMap<>();

	}

	public void set_region(int row, int col, Region r) {
		Region oldr = _regions[row][col];
		_regions[row][col] = r;

		// Aniade la lista de animales de una región antigua a la nueva
		List<Animal> oldanimals = oldr.getAnimals();
		if (!oldanimals.isEmpty()) {
			for (Animal a : oldanimals) {
				r.add_animal(a);
			}
		}

		// Update map
		this._animal_region.forEach((key, value) -> {
			if (value.equals(oldr)) {
				this._animal_region.put(key, r);
			}
		});
	}

	public void register_animal(Animal a) {
		int row, col;
		if (a.get_position() == null) {
			Vector2D newpos = Vector2D.get_random_vector_4(0.0, numRows - 1, 0.0, numCols - 1);
			a.set_pos(newpos);
			row = (int) a.get_position().getX();
			col = (int) a.get_position().getY();
		} else {
			row = (int) a.get_position().getX();
			col = (int) a.get_position().getY();
		}

		row = wrapIndex(row, numRows);
		col = wrapIndex(col, numCols);

		Region r = _regions[row][col];

		// Update list of animals
		r.add_animal(a);

		// Update map
		_animal_region.put(a, r);

		a.init(this);
	}

	public void unregister_animal(Animal a) {
		// Update map
		Region r = _animal_region.remove(a);

		// Update region
		if (r != null) {
			r.remove_animal(a);
		} else
			System.out.print("The animal couldn´t be removed");
	}

	public void update_animal_region(Animal a) {

		int row = (int) a.get_position().getX();
		int col = (int) a.get_position().getY();
		row = wrapIndex(row, numRows);
		col = wrapIndex(col, numCols);


		Region rPos = _regions[row][col];

		Region oldR = _animal_region.get(a);

		if (oldR != null) {
			// Regiosn is not equals
			if (!rPos.equals(oldR)) {
				oldR.remove_animal(a);
				rPos.add_animal(a);
				_animal_region.put(a, rPos);
			}
		} else {
			rPos.add_animal(a);
			_animal_region.put(a, rPos);
		}

	}

	public void update_all_regions(double dt) {
		for (int i = 0; i < _regions.length; i++) {
			for (int j = 0; j < _regions[i].length; j++) {
				Region region = _regions[i][j];
				region.update(dt);
			}
		}
	}

	@Override
	public int get_cols() {
		// TODO Auto-generated method stub
		return this.numCols;
	}

	@Override
	public int get_rows() {
		// TODO Auto-generated method stub
		return this.numRows;
	}

	@Override
	public int get_width() {
		// TODO Auto-generated method stub
		return this.width;
	}

	@Override
	public int get_height() {
		// TODO Auto-generated method stub
		return this.height;
	}

	@Override
	public int get_region_width() {
		// TODO Auto-generated method stub
		return this.width_Region;
	}

	@Override
	public int get_region_height() {
		// TODO Auto-generated method stub
		return this.height_Region;
	}

	@Override
	public double get_food(Animal a, double dt) {
		// TODO Auto-generated method stub
		Region oldR = _animal_region.get(a);
		return oldR.get_food(a, dt);
	}

	@Override
	public List<Animal> get_animals_in_range(Animal e, Predicate<Animal> filter) {
		List<Animal> animalsInRange = new ArrayList<>();

		// Obtener la posición del animal
		Vector2D pos = e.get_position();

		// Conseguimos posición del animal en base a su radio de vision

		int min_x = (int) (pos.getX() - e.get_sight_range()) / width_Region;
		int max_x = (int) (pos.getX() + e.get_sight_range()) / width_Region;
		int min_y = (int) (pos.getX() - e.get_sight_range()) / height_Region;
		int max_y = (int) (pos.getX() + e.get_sight_range()) / height_Region;

		// Envolver si salen del mapa
		min_x = wrapIndex(min_x, numRows);
		max_x = wrapIndex(max_x, numRows);
		min_y = wrapIndex(min_y, numCols);
		max_y = wrapIndex(max_y, numCols);

		// Recorrer las regiones dentro del campo visual
		for (int i = min_x; i <= max_x; i++) { // Navegamos entre las filas de la matriz de la región
			for (int j = min_y; j <= max_y; j++) { // Navegamosn entre las columnas de la región
				// Envolver las coordenadas si salen del mapa
				int row = wrapIndex(i, numRows);
				int col = wrapIndex(j, numCols);

				// Obtener los animales de la región actual
				Region region = _regions[row][col];
				List<Animal> animalsInRegion = region.getAnimals();

				if (!animalsInRegion.isEmpty()) {
					for (Animal a : animalsInRegion) {
						if (a.get_position().distanceTo(e.get_position()) <= e.get_sight_range() && filter.test(a)) {
							animalsInRange.add(a);
						}
					}
				}
			}
		}

		return animalsInRange;
	}

	private int wrapIndex(int index, int max) {
		while (index < 0) {
			index += max;
		}
		while (index >= max) {
			index -= max;
		}
		return index;
	}

	public JSONObject as_JSON() {
		// devuelve una estructura JSON como la siguiente donde 𝑎 es lo que
		JSONObject json = new JSONObject();
		JSONArray arrayRegiones = new JSONArray();

		for (int i = 0; i < _regions.length; i++) {
			for (int j = 0; j < _regions[i].length; j++) {
				Region region = _regions[i][j];
				JSONObject regionJSON = new JSONObject();
				regionJSON.put("row", i);
				regionJSON.put("col", j);
				regionJSON.put("data", region.as_JSON());
				arrayRegiones.put(regionJSON);
			}
		}
		json.put("regiones", arrayRegiones);
		return json;
	}

}
