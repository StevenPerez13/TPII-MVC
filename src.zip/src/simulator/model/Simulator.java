package simulator.model;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.json.JSONObject;

import simulator.factories.Factory;
import simulator.model.animal.Animal;
import simulator.model.animal.AnimalInfo;
import simulator.model.animal.State;
import simulator.model.gestorregion.MapInfo;
import simulator.model.gestorregion.RegionManager;
import simulator.model.region.Region;

public class Simulator implements JSONable {

	private Factory<Animal> animals_factory;
	private Factory<Region> regions_factory;
	private RegionManager _region_mngr;
	private List<Animal> animalsSimulator;
	private double cur_time;

	public Simulator(int cols, int rows, int width, int height, Factory<Animal> animals_factory,
			Factory<Region> regions_factory) {
		this._region_mngr = new RegionManager(cols, rows, width, height);
		if (animals_factory == null) {
			throw new IllegalArgumentException("The animals_factory can´t be null");
		}
		if (regions_factory == null) {
			throw new IllegalArgumentException("The regions_factory can´t be null");
		}
		this.animals_factory = animals_factory;
		this.regions_factory = regions_factory;
		this.animalsSimulator = new ArrayList<>();
		this.cur_time = 0.0;

	}

	private void set_region(int row, int col, Region r) {
		_region_mngr.set_region(row, col, r);
	}

	public void set_region(int row, int col, JSONObject r_json) {
		Region r = regions_factory.create_instance(r_json);
		set_region(row, col, r);
	}

	private void add_animal(Animal a) {
		animalsSimulator.add(a);
		_region_mngr.register_animal(a);
	}

	public void add_animal(JSONObject a_json) {
		Animal a = animals_factory.create_instance(a_json);
		add_animal(a);
	}

	public List<? extends AnimalInfo> get_animals() {
		List<Animal> animalsSimulatorUnmodifiable = Collections.unmodifiableList(animalsSimulator);
		return animalsSimulatorUnmodifiable;
	}

	public MapInfo get_map_info() {
		return _region_mngr;
	}

	public double get_time() {
		return cur_time;
	}

	public void advance(double dt) {
		setCur_time(cur_time + dt);
		List<Animal> animalsCopy = new ArrayList<>(animalsSimulator);
		int size = animalsCopy.size();
		for (int i = 0; i < size; i++) {
			Animal a = animalsCopy.get(i);
			if (a.get_state() == State.DEAD) {
				animalsSimulator.remove(a); // Eliminar el animal de la lista animalsSimulator directamente
				_region_mngr.unregister_animal(a);
			}
			a.update(dt);
			_region_mngr.update_animal_region(a);
			if (a.is_pregnant()) {
				Animal baby = a.deliver_baby();
				this.add_animal(baby);
			}

		}

		_region_mngr.update_all_regions(dt);

	}

	public JSONObject as_JSON() {
		JSONObject jsonSimulator = new JSONObject();
		jsonSimulator.put("time", cur_time);
		jsonSimulator.put("state", _region_mngr.as_JSON());
		return jsonSimulator;
	}

	public Factory<Animal> getAnimals_factory() {
		return animals_factory;
	}

	public void setAnimals_factory(Factory<Animal> animals_factory) {
		this.animals_factory = animals_factory;
	}

	public Factory<Region> getRegions_factory() {
		return regions_factory;
	}

	public void setRegions_factory(Factory<Region> regions_factory) {
		this.regions_factory = regions_factory;
	}

	public RegionManager get_region_mngr() {
		return _region_mngr;
	}

	public void set_region_mngr(RegionManager _region_mngr) {
		this._region_mngr = _region_mngr;
	}

	public List<Animal> getAnimalsSimulator() {
		return animalsSimulator;
	}

	public void setAnimalsSimulator(List<Animal> animalsSimulator) {
		this.animalsSimulator = animalsSimulator;
	}

	public double getCur_time() {
		return cur_time;
	}

	public void setCur_time(double cur_time) {
		this.cur_time = cur_time;
	}

}
