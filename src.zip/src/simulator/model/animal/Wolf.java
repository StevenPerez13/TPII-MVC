package simulator.model.animal;

import java.util.List;

import simulator.misc.Utils;
import simulator.misc.Vector2D;
import simulator.model.strategy.SelectClosest;
import simulator.model.strategy.SelectYoungest;
import simulator.model.strategy.SelectionStrategy;

public class Wolf extends Animal {
	private Animal _hunt_target;
	private SelectionStrategy _hunting_strategy;
	private final static double sight_range_initial = 50.0;
	private final static double init_speed = 60.0;
	private final static double fact_3 = 3.0;
	private final static double fact_10 = 10.0;
	private final static double fact_14 = 14.0;
	private final static double fact_18 = 18.0;
	private final static double fact_30 = 30.0;
	private final static double fact_50 = 50.0;

	public Wolf(SelectionStrategy mate_strategy, SelectionStrategy _hunting_strategy, Vector2D pos) {
		super("Wolf", Diet.CARNIVORE, sight_range_initial, init_speed, mate_strategy, pos);
		// Check if _hunting_strategy is not null
		if (_hunting_strategy == null) {
			throw new IllegalArgumentException("The _hunting_strategy can´t be null");
		}
		this._hunting_strategy = _hunting_strategy;
	}

	protected Wolf(Wolf p1, Animal p2) {
		super(p1, p2);
		this._hunting_strategy = p1.get_hunting_strategy();
		this._hunt_target = null;
	}

	@Override
	public void update(double dt) {
		// TODO Auto-generated method stub
		// 1. Estado de Dead no hacer nada (Volver inmediatamente

		// 2. Actualizar animal en base a estados distintos de DEAD
		if (_state != State.DEAD) {
			switch (_state) {
			case NORMAL:
				// 1.Avanzar animal
				// 1.1
				if (this.get_position().distanceTo(get_destination()) < eight_limit) {
					// Elegir otro destino de manera aleatoria, necesitamos las
					// dimensiones de la región
					Vector2D newdest = Vector2D.get_random_vector_4(0.0, _region_mngr.get_rows() - 1, 0.0,
							_region_mngr.get_cols() - 1);
					this.set_dest(newdest);
				}

				// 1.2
				double speedFinal = _speed * dt * Math.exp((_energy - max_limit) * fact_007);
				this.move(speedFinal);

				// 1.3
				double newAge = _age + dt;
				this.set_age(newAge);

				// 1.4
				double newEnergy = _energy - (fact_18 * dt);
				this.set_energy(newEnergy);
				// Mantener entre 0-100
				if (_energy < min_limit)
					this.set_energy(min_limit);

				double newDesire = _desire + (fact_30 * dt);
				this.set_desire(newDesire);
				if (this._desire > max_limit)
					this.set_desire(max_limit);

				// ------2. Cambio de estado -------

				if (_energy < fact_50) {
					this.set_state(State.HUNGER);
					this.set_mate_target(null);
				} else if (_energy >= fact_50 && _desire > fact_65) {
					this.set_state(State.MATE);
					this._hunt_target = null;
				}
				break;

			case HUNGER:

				List<Animal> targetsInRange = _region_mngr.get_animals_in_range(this,
						a -> a.get_diet() == Diet.HERBIVORE);

				// Comprueba si hay animales en su campo visual para cazar
				if (!targetsInRange.isEmpty()) {
					// 1.
					if (_hunt_target == null || _hunt_target != null && _hunt_target.get_state() == State.DEAD
							|| !targetsInRange.contains(_hunt_target)) {
						// Buscar otro animal para cazarlo
						this.set_hunting_strategy(new SelectClosest());
						Animal hunt_Closest = _hunting_strategy.select(this, targetsInRange);
						this.set_hunt_target(hunt_Closest);
					}
				}

				// 2. Como punto 1
				if (_hunt_target == null) {
					// 1.Avanzar animal
					// 1.1
					if (this.get_position().distanceTo(get_destination()) < eight_limit) {
						// Elegir otro destino de manera aleatoria, necesitamos las
						// dimensiones de la región
						Vector2D newdest = Vector2D.get_random_vector_4(0.0, _region_mngr.get_rows() - 1, 0.0,
								_region_mngr.get_cols() - 1);
						this.set_dest(newdest);
					}

					// 1.2
					double speedFinal1 = _speed * dt * Math.exp((_energy - max_limit) * fact_007);
					this.move(speedFinal1);

					// 1.3
					double newAge1 = _age + dt;
					this.set_age(newAge1);

					// 1.4
					double newEnergy1 = _energy - (fact_18 * dt);
					this.set_energy(newEnergy1);
					// Mantener entre 0-100
					if (_energy < min_limit)
						this.set_energy(min_limit);

					double newDesire1 = _desire + (fact_30 * dt);
					this.set_desire(newDesire1);
					if (this._desire > max_limit)
						this.set_desire(max_limit);

				} else if (this._hunt_target != null) {
					// 2.1
					this.set_dest(_hunt_target.get_position());

					// 2.2
					double speedFinal1 = this.get_speed() * fact_3 * dt * Math.exp((_energy - max_limit) * fact_007);
					this.move(speedFinal1);

					// 2.3
					double newAge1 = _age + dt;
					this.set_age(newAge1);

					// 2.4
					double newEnergy1 = _energy - (fact_18 * fact_1_2 * dt);
					this.set_energy(newEnergy1);
					// Mantener entre 0-100
					if (_energy < min_limit)
						this.set_energy(min_limit);

					// 2.5
					double newDesire1 = _desire + (fact_30 * dt);
					this.set_desire(newDesire1);
					if (_desire > max_limit)
						this.set_desire(max_limit);

					// 2.6
					if (_pos.distanceTo(_hunt_target.get_position()) < eight_limit) {

						_hunt_target.set_state(State.DEAD);
						this.set_hunt_target(null);
						this.set_energy(_energy + fact_50);
						if (_energy > max_limit)
							this.set_desire(max_limit);
					}
				}
				// 3. Cambio de Estado

				// 3.1
				if (_energy > fact_50) {
					if (_desire < fact_65) {
						this.set_state(State.NORMAL);
						this.set_hunt_target(null);
						this.set_mate_target(null);
					} else {
						this.set_state(State.MATE);
						this.set_hunt_target(null);
					}
				}
				// 3.2 NOTHING
				break;

			case MATE:
				// 1
				List<Animal> targetsInRangeMate = _region_mngr.get_animals_in_range(this,
						a -> a.get_genetic_code() == "Sheep");
				if (targetsInRangeMate.isEmpty())
					this.set_mate_target(null);
				else if (_mate_target != null && _mate_target.get_state() == State.DEAD
						|| !targetsInRangeMate.contains(_mate_target))
					this.set_mate_target(null);

				if (_mate_target == null) {
					if (targetsInRangeMate.isEmpty()) { // No encuentra con quien emparejarse
						// punto 1 del Caso Normal
						// 1.Avanzar animal
						// 1.1
						if (this.get_position().distanceTo(get_destination()) < eight_limit) {
							// Elegir otro destino de manera aleatoria, necesitamos las
							// dimensiones de la región
							Vector2D newdest = Vector2D.get_random_vector_4(0.0, _region_mngr.get_rows() - 1, 0.0,
									_region_mngr.get_cols() - 1);
							this.set_dest(newdest);
						}

						// 1.2
						double speedFinal2 = _speed * dt * Math.exp((_energy - max_limit) * fact_007);
						this.move(speedFinal2);

						// 1.3
						double newAge2 = _age + dt;
						this.set_age(newAge2);

						// 1.4
						double newEnergy2 = _energy - (fact_18 * dt);
						this.set_energy(newEnergy2);
						// Mantener entre 0-100
						if (_energy < min_limit)
							this.set_energy(min_limit);

						double newDesire2 = _desire + (fact_30 * dt);
						this.set_desire(newDesire2);
						if (this._desire > max_limit)
							this.set_desire(max_limit);

					} else {
						// Selecciona con quien emparajarse
						// Va a seleccionar al más joven para emparejarse
						this.set_mate_strategy(new SelectYoungest());
						Animal mate_Youngest = _mate_strategy.select(this, targetsInRangeMate);
						this.set_mate_target(mate_Youngest);

						// 2.1
						this.set_dest(_mate_target.get_position());

						// 2.2
						double speedFinal3 = _speed * fact_3 * dt * Math.exp((_energy - max_limit) * fact_007);
						this.move(speedFinal3);

						// 2.3
						double newAge3 = _age + dt;
						this.set_age(newAge3);

						// 2.4
						double newEnergy3 = _energy - (fact_18 * fact_1_2 * dt);
						this.set_energy(newEnergy3);
						// Mantener entre 0-100
						if (_energy < min_limit)
							this.set_energy(min_limit);

						// 2.5
						double newDesire3 = _desire + (fact_30 * dt);
						this.set_desire(newDesire3);
						if (_desire > max_limit)
							this.set_desire(max_limit);

						// 2.6
						if (_pos.distanceTo(_mate_target.get_position()) < eight_limit) {
							// 2.6.1
							this.set_desire(0.0);
							_mate_target.set_desire(0.0);

							// 2.6.2
							if (_baby == null) {
								// Generar nuevo numero aleatorio
								double randomNumber = Utils._rand.nextDouble();
								if (randomNumber <= fact_009) {
									// Va a haber un nuevo bebe
									Animal baby = new Wolf(this, _mate_target);
									this.set_baby(baby);
								}
							}
							// 2.6.3
							this.set_energy(_energy - fact_10);
							// Mantener entre 0-100
							if (_energy < min_limit)
								this.set_energy(min_limit);
							// 2.6.4
							this.set_mate_target(null);
						}
					}

				}

				// 3
				if (_energy < fact_50) {
					this.set_state(State.HUNGER);
					this.set_mate_target(null);
				} else if (_energy >= fact_50 && _desire < fact_65) {
					this.set_state(State.NORMAL);
					this.set_hunt_target(null);
					this.set_mate_target(null);
					;
				}

				break;

			default:
				throw new IllegalArgumentException("state don´t know");
			}

			// 3. Si la posición está fuera del mapa, ajustarla y cambiar su estado a
			// NORMAL.
			if (_pos.getX() >= _region_mngr.get_rows() || _pos.getX() < 0 || _pos.getY() >= _region_mngr.get_cols()
					|| _pos.getY() < 0) {
				double x_final = _pos.getX(), y_final = _pos.getY();
				while (x_final >= _region_mngr.get_rows()) {
					x_final -=  _region_mngr.get_rows();
				}
					
				while (x_final < 0) {
					x_final += _region_mngr.get_rows();

				}
				while (y_final >= _region_mngr.get_cols()) {
					y_final -=  _region_mngr.get_cols();

				}
				while (y_final < 0) {
					y_final +=  _region_mngr.get_cols();

				}

				Vector2D _newPos = new Vector2D(x_final, y_final);
				_pos = _newPos;

				this.set_state(State.NORMAL);
				this.set_hunt_target(null);
				this.set_mate_target(null);

			}

			// 4. Si _energy es 0.0 o _age es mayor de 8.0, cambia su estado a DEAD.
			if (this.get_energy() == 0.0 || this.get_age() > fact_14)
				this.set_state(State.DEAD);

			// 5.Si su estado no es DEAD, pide comida al gestor de regiones usando
			// get_food(this, dt) y añadela a
			// su _energy (manteniéndolo siempre entre 0.0 y 100.0)
			if (this.get_state() != State.DEAD) {
				double new_energy = _region_mngr.get_food(this, dt);
				this.set_energy(new_energy);
				;
				if (this.get_energy() > max_limit)
					this.set_energy(max_limit);
			}

		}

	}

	public Animal get_hunt_target() {
		return _hunt_target;
	}

	public void set_hunt_target(Animal _hunt_target) {
		this._hunt_target = _hunt_target;
	}

	public SelectionStrategy get_hunting_strategy() {
		return _hunting_strategy;
	}

	public void set_hunting_strategy(SelectionStrategy _hunting_strategy) {
		this._hunting_strategy = _hunting_strategy;
	}

	@Override
	public Vector2D get_position() {
		return _pos;
	}

	@Override
	public Vector2D get_destination() {
		return _dest;
	}

	@Override
	public boolean is_pregnant() {
		if (_baby != null)
			return true;
		else
			return false;
	}

	@Override
	public State get_state() {
		// TODO Auto-generated method stub
		return _state;
	}

	@Override
	public String get_genetic_code() {
		// TODO Auto-generated method stub
		return _genetic_code;
	}

	@Override
	public Diet get_diet() {
		// TODO Auto-generated method stub
		return _diet;
	}

	@Override
	public double get_speed() {
		// TODO Auto-generated method stub
		return _speed;
	}

	@Override
	public double get_sight_range() {
		// TODO Auto-generated method stub
		return _sight_range;
	}

	@Override
	public double get_energy() {
		// TODO Auto-generated method stub
		return _energy;
	}

	@Override
	public double get_age() {
		// TODO Auto-generated method stub
		return _age;
	}

	@Override
	public double get_desire() {
		// TODO Auto-generated method stub
		return _desire;
	}

}
