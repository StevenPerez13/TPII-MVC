package simulator.model.animal;

import java.util.List;

import simulator.misc.Utils;
import simulator.misc.Vector2D;
import simulator.model.strategy.SelectClosest;
import simulator.model.strategy.SelectYoungest;
import simulator.model.strategy.SelectionStrategy;

public class Sheep extends Animal {
	private Animal _danger_source;
	private SelectionStrategy _danger_strategy;
	private final static double sight_range_initial = 40.0;
	private final static double init_speed = 35.0;
	private final static double fact_2 = 2.0;
	private final static double fact_20 = 20.0;
	private final static double fact_40 = 40.0;

	public Sheep(SelectionStrategy mate_strategy, SelectionStrategy danger_strategy, Vector2D pos) {
		super("Sheep", Diet.HERBIVORE, sight_range_initial, init_speed, mate_strategy, pos);
		// Check if danger_strategy is not null
		if (danger_strategy == null) {
			throw new IllegalArgumentException("The danger_strategy can´t be null");
		}
		this._danger_strategy = danger_strategy;
	}

	protected Sheep(Sheep p1, Animal p2) {
		super(p1, p2);
		this._danger_strategy = p1.get_danger_strategy();
		this._danger_source = null;
	}

	@Override
	public void update(double dt) {
		// 1. Estado de Dead no hacer nada (volver inmediatamente)
		// 2. Actualizar animal en base a estados distintos de DEAD
		if (_state != State.DEAD) {
			switch (_state) {
			case NORMAL:
				// 1.Avanzar animal
				// 1.1
				if (get_position().distanceTo(get_destination()) < eight_limit) {
					// Elegir otro destino de manera aleatoria, necesitamos las
					// dimensiones de la región
					Vector2D newdest = Vector2D.get_random_vector_4(0.0, _region_mngr.get_rows() - 1, 0.0,
							_region_mngr.get_cols() - 1);
					this.set_dest(newdest);
				}

				// 1.2
				double speedFinal = _speed * dt * Math.exp((_energy - max_limit) * fact_007);
				this.move(speedFinal);

				// 1.3
				double newAge = _age + dt;
				this.set_age(newAge);

				// 1.4
				double newEnergy = _energy - (fact_20 * dt);
				this.set_energy(newEnergy);
				// Mantener entre 0-100
				if (_energy < min_limit)
					this.set_energy(min_limit);

				// 1.5
				double newDesire = _desire + (fact_40 * dt);
				this.set_desire(newDesire);
				if (this._desire > max_limit)
					this.set_desire(max_limit);

				// ------2. Cambio de estado -------

				// 2.1
				if (_danger_source == null) {
					List<Animal> carnivoresInRange = _region_mngr.get_animals_in_range(this,
							a -> a.get_diet() == Diet.CARNIVORE);
					if (!carnivoresInRange.isEmpty()) {
						this.set_danger_strategy(new SelectClosest());
						// Animal más peligrosos es el carnivoro más cercano
						Animal dangerous = _danger_strategy.select(this, carnivoresInRange);
						this.set_danger_source(dangerous);
					}

				} else if (_danger_source != null) // 2.2.1
				{
					this.set_state(State.DANGER);
					this.set_mate_target(null);
				} else if (_danger_source == null && _desire > fact_65) // 2.2.2
				{
					this.set_state(State.MATE);
					this.set_danger_source(null);
				}

				break;

			case DANGER:
				// 1.
				if (_danger_source != null && _danger_source.get_state() == State.DEAD) {
					this.set_danger_source(null);// The sheep is dead
				}
				// 2. Como punto 1
				else if (_danger_source == null) {
					// 1. Caso NORMAL
					// 1.Avanzar animal
					// 1.1
					if (get_position().distanceTo(get_destination()) < eight_limit) {
						// Elegir otro destino de manera aleatoria, necesitamos las
						// dimensiones de la región
						Vector2D newdest = Vector2D.get_random_vector_4(0.0, _region_mngr.get_rows() - 1, 0.0,
								_region_mngr.get_cols() - 1);
						this.set_dest(newdest);
					}

					// 1.2
					double speedFinal1 = _speed * dt * Math.exp((_energy - max_limit) * fact_007);
					this.move(speedFinal1);

					// 1.3
					double newAge1 = _age + dt;
					this.set_age(newAge1);

					// 1.4
					double newEnergy1 = _energy - (fact_20 * dt);
					this.set_energy(newEnergy1);
					// Mantener entre 0-100
					if (_energy < min_limit)
						this.set_energy(min_limit);

					// 1.5
					double newDesire1 = _desire + (fact_40 * dt);
					this.set_desire(newDesire1);
					if (_desire > max_limit)
						this.set_desire(max_limit);

				} else if (_danger_source != null) { // 2.1
					// 2.1
					this.set_dest(_pos.plus(_pos.minus(_danger_source.get_position()).direction()));

					// 2.2
					double speedFinal1 = _speed * fact_2 * dt * Math.exp((_energy - max_limit) * fact_007);
					this.move(speedFinal1);

					// 2.3
					this.set_age(_age + dt);

					// 2.4
					double newEnergy1 = _energy - (fact_20 * fact_1_2 * dt);
					this.set_energy(newEnergy1);
					// Mantener entre 0-100
					if (_energy < min_limit)
						this.set_energy(min_limit);

					// 2.5
					double newDesire1 = _desire + (fact_40 * dt);
					this.set_desire(newDesire1);
					if (_desire > 100)
						this.set_desire(100);
				}

				// 3. Cambio de Estado
				// 3.1
				List<Animal> carnivoresInRange1 = _region_mngr.get_animals_in_range(this,
						a -> a.get_diet() == Diet.CARNIVORE);
				// Compruebo que la lista no este vacía
				if (!carnivoresInRange1.isEmpty()) {
					if (_danger_source == null || !carnivoresInRange1.contains(_danger_source)) {
						// 3.1.1 buscar un nuevo animal que se considere como peligro. (En este caso el
						// más cercano)
						this.set_danger_strategy(new SelectClosest());
						Animal dangerous = _danger_strategy.select(this, carnivoresInRange1);
						this.set_danger_source(dangerous);

						// 3.1.2
						if (_danger_source == null) {
							if (_desire < fact_65) {
								this.set_state(State.NORMAL);
								this.set_danger_source(null);
								this.set_mate_target(null);
							} else {
								this.set_state(State.MATE);
								this.set_danger_source(null);
							}
						}
					}
				} else {
					// 3.1.2
					if (_danger_source == null) {
						if (this.get_desire() < fact_65) {
							this.set_state(State.NORMAL);
							this.set_danger_source(null);
							this.set_mate_target(null);
						} else {
							this.set_state(State.MATE);
							this.set_danger_source(null);
						}
					}
				}

				break;

			case MATE:
				// 1.
				List<Animal> targetsInRange = _region_mngr.get_animals_in_range(this,
						a -> a.get_genetic_code() == "Sheep");
				if (targetsInRange.isEmpty())
					this.set_mate_target(null);
				else if (_mate_target != null && _mate_target.get_state() == State.DEAD
						|| !targetsInRange.contains(_mate_target))
					this.set_mate_target(null);

				// 2.
				if (_mate_target == null) {
					if (targetsInRange.isEmpty()) { // No encuentra con quien emparejarse
						// punto 1 del Caso Normal
						// 1.Avanzar animal
						// 1.1
						if (get_position().distanceTo(get_destination()) < eight_limit) {
							// Elegir otro destino de manera aleatoria, necesitamos las
							// dimensiones de la región
							Vector2D newdest = Vector2D.get_random_vector_4(0.0, _region_mngr.get_rows() - 1, 0.0,
									_region_mngr.get_cols() - 1);
							this.set_dest(newdest);
						}

						// 1.2
						double speedFinal2 = _speed * dt * Math.exp((_energy - max_limit) * fact_007);
						this.move(speedFinal2);

						// 1.3
						double newAge2 = _age + dt;
						this.set_age(newAge2);

						// 1.4
						double newEnergy2 = _energy - (fact_20 * dt);
						this.set_energy(newEnergy2);
						// Mantener entre 0-100
						if (_energy < min_limit)
							this.set_energy(min_limit);

						// 1.5
						double newDesire2 = _desire + (fact_40 * dt);
						this.set_desire(newDesire2);
						if (this._desire > max_limit)
							this.set_desire(max_limit);

					} else {
						// Selecciona con quien emparajarse
						// Va a seleccionar al más joven para emparejarse
						this.set_mate_strategy(new SelectYoungest());
						Animal mate_Youngest = _mate_strategy.select(this, targetsInRange);
						this.set_mate_target(mate_Youngest);

						// 2.1
						this.set_dest(_mate_target.get_position());

						// 2.2
						double speedFinal3 = _speed * fact_2 * dt * Math.exp((_energy - max_limit) * fact_007);
						this.move(speedFinal3);

						// 2.3
						double newAge3 = _age + dt;
						this.set_age(newAge3);

						// 2.4
						double newEnergy3 = _energy - (fact_20 * fact_1_2 * dt);
						this.set_energy(newEnergy3);
						// Mantener entre 0-100
						if (_energy < min_limit)
							this.set_energy(min_limit);

						// 2.5
						double newDesire3 = _desire + (fact_40 * dt);
						this.set_desire(newDesire3);
						if (_desire > max_limit)
							this.set_desire(max_limit);

						// 2.6
						if (_pos.distanceTo(_mate_target.get_position()) < eight_limit) {
							// 2.6.1
							this.set_desire(0.0);
							_mate_target.set_desire(0.0);

							// 2.6.2
							if (_baby == null) {
								// Generar nuevo numero aleatorio
								double randomNumber = Utils._rand.nextDouble();
								if (randomNumber <= fact_009) {
									// Va a haber un nuevo bebe
									Animal baby = new Sheep(this, _mate_target);
									this.set_baby(baby);
								}
							}
							// 2.6.3
							this.set_mate_target(null);
						}
					}

				}

				// 3
				if (this.get_danger_source() == null) {
					List<Animal> carnivoresInRange2 = _region_mngr.get_animals_in_range(this,
							a -> a.get_diet() == Diet.CARNIVORE);
					if (!carnivoresInRange2.isEmpty()) {
						this.set_danger_strategy(new SelectClosest());
						// Animal más peligrosos es el carnivoro más cercano
						Animal dangerous = _danger_strategy.select(this, carnivoresInRange2);
						this.set_danger_source(dangerous);
					}
				}
				// 4
				if (_danger_source != null) {
					this.set_state(State.DANGER);
					this.set_mate_target(null);
				} else if (_danger_source == null && _desire < fact_65) {
					this.set_state(State.NORMAL);
					this.set_danger_source(null);
					this.set_mate_target(null);
				}

				break;

			default:
				throw new IllegalArgumentException("state don´t know");
			}

			// 3. Si la posición está fuera del mapa, ajustarla y cambiar su estado a
			// NORMAL.
			if (_pos.getX() >= _region_mngr.get_rows() || _pos.getX() < 0 || _pos.getY() >= _region_mngr.get_cols()
					|| _pos.getY() < 0) {
				double x_final = _pos.getX(), y_final = _pos.getY();
				while (x_final >= _region_mngr.get_rows()) {
					x_final -= _region_mngr.get_rows();
				}

				while (x_final < 0) {
					x_final += _region_mngr.get_rows();

				}
				while (y_final >= _region_mngr.get_cols()) {
					y_final -= _region_mngr.get_cols();

				}
				while (y_final < 0) {
					y_final += _region_mngr.get_cols();

				}

				Vector2D _newPos = new Vector2D(x_final, y_final);
				_pos = _newPos;

				this.set_state(State.NORMAL);
				this.set_danger_source(null);
				this.set_mate_target(null);

			}

			// 4. Si _energy es 0.0 o _age es mayor de 8.0, cambia su estado a DEAD.
			if (this.get_energy() == 0.0 || this.get_age() > eight_limit) {
				this.set_state(State.DEAD);
			}

			// 5.Si su estado no es DEAD, pide comida al gestor de regiones usando
			// get_food(this, dt) y añadela a
			// su _energy (manteniéndolo siempre entre 0.0 y 100.0)
			if (this.get_state() != State.DEAD) {
				double new_energy = _region_mngr.get_food(this, dt);
				this.set_energy(new_energy);
				;
				if (this.get_energy() > max_limit)
					this.set_energy(max_limit);
			}

		}

	}

	public Animal get_danger_source() {
		return _danger_source;
	}

	public void set_danger_source(Animal _danger_source) {
		this._danger_source = _danger_source;
	}

	public SelectionStrategy get_danger_strategy() {
		return _danger_strategy;
	}

	public void set_danger_strategy(SelectionStrategy _danger_strategy) {
		this._danger_strategy = _danger_strategy;
	}

	@Override
	public Vector2D get_position() {
		return _pos;
	}

	@Override
	public Vector2D get_destination() {
		return _dest;
	}

	@Override
	public boolean is_pregnant() {
		if (_baby != null)
			return true;
		else
			return false;
	}

	@Override
	public State get_state() {
		// TODO Auto-generated method stub
		return _state;
	}

	@Override
	public String get_genetic_code() {
		// TODO Auto-generated method stub
		return _genetic_code;
	}

	@Override
	public Diet get_diet() {
		// TODO Auto-generated method stub
		return _diet;
	}

	@Override
	public double get_speed() {
		// TODO Auto-generated method stub
		return _speed;
	}

	@Override
	public double get_sight_range() {
		// TODO Auto-generated method stub
		return _sight_range;
	}

	@Override
	public double get_energy() {
		// TODO Auto-generated method stub
		return _energy;
	}

	@Override
	public double get_age() {
		// TODO Auto-generated method stub
		return _age;
	}

	@Override
	public double get_desire() {
		// TODO Auto-generated method stub
		return _desire;
	}
}
