package simulator.factories;

import org.json.JSONObject;

import simulator.model.region.DynamicSupplyRegion;
import simulator.model.region.Region;

public class DynamicSupplyRegionBuilder extends Builder<Region> {

	public DynamicSupplyRegionBuilder() {
		super("dynamic", "Selection of region with Builder");
	}

	@Override
	protected Region create_instance(JSONObject data) {
		if (data == null) {
			throw new IllegalArgumentException("información data vacía ");
		}
		double factor = data.has("factor") ? data.getDouble("factor") : 2.0;
		double food = data.has("food") ? data.getDouble("food") : 1000.0;
		return new DynamicSupplyRegion(food, factor);
	}
}
